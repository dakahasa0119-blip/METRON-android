package proxyhand.android

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request

object JsManager {

    private val client = OkHttpClient()

    private const val JS_BASE_URL =
        "https://script.google.com/macros/s/AKfycbz4WrLd0eOkYHNOKhziYtEpP7gBs02hgnzWL_OFNNAOmpSUJySEf7p9uYBa-R8pW-M/exec"

    private val cache = mutableMapOf<String, String>()

    fun init(context: Context) {
        fetchJs("gemini")
        fetchJs("chatgpt")
        fetchJs("copilot")
    }

    fun getJs(target: String, prompt: String): String {
        val base = cache[target] ?: fetchJs(target)
        val safePrompt = prompt.toJsString()
        return base.replace("{{PROMPT}}", safePrompt)
    }

    private fun fetchJs(target: String): String {
        val url = "$JS_BASE_URL?target=$target"
        val req = Request.Builder().url(url).build()
        return try {
            client.newCall(req).execute().use { res ->
                val body = res.body?.string() ?: ""
                cache[target] = body
                body
            }
        } catch (e: Exception) {
            val fallback = "(function(){alert('JS load failed for $target');})();"
            cache[target] = fallback
            fallback
        }
    }

    private fun String.toJsString(): String =
        replace("\\", "\\\\").replace("\"", "\\\"").let { "\"$it\"" }
}
