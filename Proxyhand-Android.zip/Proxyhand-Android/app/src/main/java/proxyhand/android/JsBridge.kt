package proxyhand.android

import android.webkit.JavascriptInterface

class JsBridge(
    private val onMessage: (String) -> Unit
) {

    @JavascriptInterface
    fun send(text: String) {
        onMessage(text)
    }
}
