package proxyhand.android

import fi.iki.elonen.NanoHTTPD

class LocalHttpServer(
    port: Int,
    private val handler: (String, String?) -> String
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        val method = session.method

        var body: String? = null
        if (method == Method.POST) {
            val map = HashMap<String, String>()
            session.parseBody(map)
            body = map["postData"]
        }

        val result = handler(uri, body)
        return newFixedLengthResponse(result)
    }
}
