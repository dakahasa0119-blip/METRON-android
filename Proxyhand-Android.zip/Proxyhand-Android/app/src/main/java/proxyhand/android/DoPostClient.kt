package proxyhand.android

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody

object DoPostClient {

    private val client = OkHttpClient()

    private const val GAS_URL =
        "https://script.google.com/macros/s/AKfycbz4WrLd0eOkYHNOKhziYtEpP7gBs02hgnzWL_OFNNAOmpSUJySEf7p9uYBa-R8pW-M/exec"

    fun sendToGas(answer: String) {
        val json = """{"source":"ARC","text":${answer.quoteJson()}}"""
        val body = RequestBody.create("application/json".toMediaType(), json)
        val request = Request.Builder()
            .url(GAS_URL)
            .post(body)
            .build()

        Thread {
            try {
                client.newCall(request).execute().use { }
            } catch (_: Exception) {}
        }.start()
    }

    private fun String.quoteJson(): String =
        replace("\\", "\\\\").replace("\"", "\\\"").let { "\"$it\"" }
}
