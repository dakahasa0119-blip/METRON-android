package proxyhand.android

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import proxyhand.android.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var server: LocalHttpServer

    private val geminiUrl = "https://gemini.google.com/"
    private val chatGptUrl = "https://chat.openai.com/"
    private val copilotUrl = "https://copilot.microsoft.com/"

    private var currentTarget: AiTarget = AiTarget.GEMINI

    enum class AiTarget {
        GEMINI, CHATGPT, COPILOT, ALL
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        startService(Intent(this, MetronService::class.java))

        setupWebView(binding.webView)

        JsManager.init(this)

        server = LocalHttpServer(8080) { path, body ->
            when (path) {
                "/command" -> {
                    val prompt = body ?: ""
                    runOnUiThread {
                        injectPromptToCurrentAi(prompt)
                    }
                    "OK"
                }
                "/result" -> {
                    val result = body ?: ""
                    DoPostClient.sendToGas(result)
                    "RECEIVED"
                }
                else -> "NG"
            }
        }
        server.start()

        setupButtons()
        loadAi(AiTarget.GEMINI)
    }

    private fun setupButtons() {
        binding.btnGemini.setOnClickListener {
            currentTarget = AiTarget.GEMINI
            loadAi(AiTarget.GEMINI)
        }
        binding.btnChatGPT.setOnClickListener {
            currentTarget = AiTarget.CHATGPT
            loadAi(AiTarget.CHATGPT)
        }
        binding.btnCopilot.setOnClickListener {
            currentTarget = AiTarget.COPILOT
            loadAi(AiTarget.COPILOT)
        }
        binding.btnAll.setOnClickListener {
            currentTarget = AiTarget.ALL
            loadAi(AiTarget.GEMINI)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(webView: WebView) {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.userAgentString =
            settings.userAgentString + " Chrome/120.0.0.0"

        webView.webViewClient = object : WebViewClient() {}
        webView.webChromeClient = WebChromeClient()

        webView.addJavascriptInterface(JsBridge { text ->
            DoPostClient.sendToGas(text)
        }, "AndroidBridge")
    }

    private fun loadAi(target: AiTarget) {
        val url = when (target) {
            AiTarget.GEMINI -> geminiUrl
            AiTarget.CHATGPT -> chatGptUrl
            AiTarget.COPILOT -> copilotUrl
            AiTarget.ALL -> geminiUrl
        }
        binding.webView.loadUrl(url)
    }

    private fun injectPromptToCurrentAi(prompt: String) {
        val js = when (currentTarget) {
            AiTarget.GEMINI -> JsManager.getJs("gemini", prompt)
            AiTarget.CHATGPT -> JsManager.getJs("chatgpt", prompt)
            AiTarget.COPILOT -> JsManager.getJs("copilot", prompt)
            AiTarget.ALL -> JsManager.getJs("gemini", prompt)
        }
        binding.webView.evaluateJavascript(js, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        server.stop()
    }
}
