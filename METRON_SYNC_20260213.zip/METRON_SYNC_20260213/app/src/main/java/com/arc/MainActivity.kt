package com.arc

import android.content.Context

class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("arc_settings", Context.MODE_PRIVATE)

    // GAS
    var gasUrl: String
        get() = sp.getString("gas_url", "")!!
        set(v) = sp.edit().putString("gas_url", v).apply()

    var sheetId: String
        get() = sp.getString("sheet_id", "")!!
        set(v) = sp.edit().putString("sheet_id", v).apply()

    // AI URLs
    var geminiUrl: String
        get() = sp.getString("gemini_url", "https://gemini.google.com/")!!
        set(v) = sp.edit().putString("gemini_url", v).apply()

    var chatGptUrl: String
        get() = sp.getString("chatgpt_url", "https://chat.openai.com/")!!
        set(v) = sp.edit().putString("chatgpt_url", v).apply()

    var copilotUrl: String
        get() = sp.getString("copilot_url", "https://copilot.microsoft.com/")!!
        set(v) = sp.edit().putString("copilot_url", v).apply()

    // DOM selectors – Gemini
    var geminiInputSelector: String
        get() = sp.getString("gemini_input", "textarea")!!
        set(v) = sp.edit().putString("gemini_input", v).apply()

    var geminiSendSelector: String
        get() = sp.getString("gemini_send", "button[type='submit']")!!
        set(v) = sp.edit().putString("gemini_send", v).apply()

    var geminiResponseSelector: String
        get() = sp.getString("gemini_resp", "article")!!
        set(v) = sp.edit().putString("gemini_resp", v).apply()

    // DOM selectors – ChatGPT
    var chatGptInputSelector: String
        get() = sp.getString("chatgpt_input", "textarea")!!
        set(v) = sp.edit().putString("chatgpt_input", v).apply()

    var chatGptSendSelector: String
        get() = sp.getString("chatgpt_send", "button[type='submit']")!!
        set(v) = sp.edit().putString("chatgpt_send", v).apply()

    var chatGptResponseSelector: String
        get() = sp.getString("chatgpt_resp", "article")!!
        set(v) = sp.edit().putString("chatgpt_resp", v).apply()

    // DOM selectors – Copilot
    var copilotInputSelector: String
        get() = sp.getString("copilot_input", "textarea")!!
        set(v) = sp.edit().putString("copilot_input", v).apply()

    var copilotSendSelector: String
        get() = sp.getString("copilot_send", "button[type='submit']")!!
        set(v) = sp.edit().putString("copilot_send", v).apply()

    var copilotResponseSelector: String
        get() = sp.getString("copilot_resp", "article")!!
        set(v) = sp.edit().putString("copilot_resp", v).apply()

    // 🔥 現在選択中の人格スロット
    var selectedSlotIndex: Int
        get() = sp.getInt("selected_slot_index", 0)
        set(v) = sp.edit().putInt("selected_slot_index", v).apply()

    // 🔥 人格スロット（3つ）
    var profileSlot1: String
        get() = sp.getString("profile_slot_1", DEFAULT_CONSULT_JSON)!!
        set(v) = sp.edit().putString("profile_slot_1", v).apply()

    var profileSlot2: String
        get() = sp.getString("profile_slot_2", DEFAULT_CODE_JSON)!!
        set(v) = sp.edit().putString("profile_slot_2", v).apply()

    var profileSlot3: String
        get() = sp.getString("profile_slot_3", DEFAULT_EXPERIMENT_JSON)!!
        set(v) = sp.edit().putString("profile_slot_3", v).apply()

    // ALL AI 設定（人格スロットから上書きされる）
    var allAiMode: String
        get() = sp.getString("all_ai_mode", "summary")!!
        set(v) = sp.edit().putString("all_ai_mode", v).apply()

    var summaryPrompt: String
        get() = sp.getString("summary_prompt", "")!!
        set(v) = sp.edit().putString("summary_prompt", v).apply()

    var hallucinationTolerance: String
        get() = sp.getString("hallucination_tolerance", "normal")!!
        set(v) = sp.edit().putString("hallucination_tolerance", v).apply()

    var allAiDelayMs: Long
        get() = sp.getLong("all_ai_delay", 1500)
        set(v) = sp.edit().putLong("all_ai_delay", v).apply()

    companion object {

        // 相談用
        const val DEFAULT_CONSULT_JSON = """
        {
          "name": "相談用",
          "all_ai_mode": "summary",
          "summary_prompt": "以下の3つの回答を統合し、矛盾点を整理し、最も妥当な結論を1つにまとめてください。\n\n{CONTENT}",
          "hallucination_tolerance": "strict",
          "all_ai_delay_ms": 1500
        }
        """

        // コード生成用
        const val DEFAULT_CODE_JSON = """
        {
          "name": "コード生成用",
          "all_ai_mode": "summary",
          "summary_prompt": "以下の3つの回答を統合し、最も簡潔で正確なコードのみを返してください。不要な文章は省いてください。\n\n{CONTENT}",
          "hallucination_tolerance": "strict",
          "all_ai_delay_ms": 800
        }
        """

        // 実験用（編集可能）
        const val DEFAULT_EXPERIMENT_JSON = """
        {
          "name": "実験用",
          "all_ai_mode": "separate",
          "summary_prompt": "以下の3つの回答を比較し、差分を抽出してください。\n\n{CONTENT}",
          "hallucination_tolerance": "normal",
          "all_ai_delay_ms": 500
        }
        """
    }
}
