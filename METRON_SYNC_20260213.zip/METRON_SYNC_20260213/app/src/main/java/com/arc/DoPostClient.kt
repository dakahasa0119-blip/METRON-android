package com.arc

import okhttp3.*
import java.io.IOException

object DoPostClient {

    private val client = OkHttpClient()

    fun sendToGas(url: String, sheetId: String, text: String, tag: String = "ARC") {
        if (url.isBlank()) return

        val body = FormBody.Builder()
            .add("sheet", sheetId)
            .add("text", text)
            .add("tag", tag)
            .build()

        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // ログ送信失敗は無視（ARC は止まらない）
            }

            override fun onResponse(call: Call, response: Response) {
                response.close()
            }
        })
    }
}
