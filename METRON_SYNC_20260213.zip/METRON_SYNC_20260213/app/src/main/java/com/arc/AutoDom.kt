package com.arc

import org.json.JSONObject

object AutoDom {

    fun handleAutoDomJson(
        json: String,
        currentTarget: AiTarget,
        prefs: Prefs
    ) {
        val obj = JSONObject(json)
        val input = obj.optString("input", null)
        val send = obj.optString("send", null)
        val resp = obj.optString("response", null)

        when (currentTarget) {
            AiTarget.GEMINI -> {
                if (!input.isNullOrEmpty()) prefs.geminiInputSelector = input
                if (!send.isNullOrEmpty()) prefs.geminiSendSelector = send
                if (!resp.isNullOrEmpty()) prefs.geminiResponseSelector = resp
            }
            AiTarget.CHATGPT -> {
                if (!input.isNullOrEmpty()) prefs.chatGptInputSelector = input
                if (!send.isNullOrEmpty()) prefs.chatGptSendSelector = send
                if (!resp.isNullOrEmpty()) prefs.chatGptResponseSelector = resp
            }
            AiTarget.COPILOT -> {
                if (!input.isNullOrEmpty()) prefs.copilotInputSelector = input
                if (!send.isNullOrEmpty()) prefs.copilotSendSelector = send
                if (!resp.isNullOrEmpty()) prefs.copilotResponseSelector = resp
            }
            else -> {}
        }
    }

    // WebView に注入する Auto‑DOM スクリプト
    fun script(): String = """
        (function() {
          function findInput() {
            return document.querySelector("textarea, [contenteditable='true']");
          }
          function findSend() {
            return document.querySelector("button[type='submit'], button[aria-label*='Send'], button");
          }
          function findResponse() {
            return document.querySelector("[data-message-author-role='assistant'], article, div[role='article'], div");
          }
          function getSelector(el) {
            if (!el) return null;
            if (el.id) return "#" + el.id;
            if (el.className) return "." + String(el.className).split(" ").join(".");
            return el.tagName.toLowerCase();
          }
          const result = {
            input: getSelector(findInput()),
            send: getSelector(findSend()),
            response: getSelector(findResponse())
          };
          if (window.AndroidBridge && window.AndroidBridge.autoDom) {
            window.AndroidBridge.autoDom(JSON.stringify(result));
          }
        })();
    """.trimIndent()
}
