package com.arc

import fi.iki.elonen.NanoHTTPD

class LocalHttpServer(port: Int = 8765) : NanoHTTPD(port) {

    private var handler: ((String) -> String)? = null

    fun setHandler(h: (String) -> String) {
        handler = h
    }

    override fun serve(session: IHTTPSession): Response {
        val msg = session.parms["msg"] ?: ""
        val result = handler?.invoke(msg) ?: ""
        return newFixedLengthResponse(result)
    }
}
