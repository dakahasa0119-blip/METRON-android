package com.arc

enum class AiTarget {
    GEMINI,
    CHATGPT,
    COPILOT,
    ALL
}
