package com.arc

import android.os.Handler
import android.os.Looper

class HallucinationPipeline(
    private val prefs: Prefs,
    private val loadAi: (AiTarget) -> Unit,
    private val injectPrompt: (String) -> Unit
) {

    private var onDone: ((String) -> Unit)? = null
    private var summaryBuffer = ""

    fun process(results: List<String>, callback: (String) -> Unit) {
        onDone = callback

        val combined = results.joinToString("\n\n---\n\n")
        val summaryPrompt = prefs.summaryPrompt.replace("{CONTENT}", combined)

        loadAi(AiTarget.GEMINI)

        Handler(Looper.getMainLooper()).postDelayed({
            injectPrompt(summaryPrompt)
        }, prefs.allAiDelayMs)
    }

    fun onSummaryResult(text: String) {
        summaryBuffer = text

        loadAi(AiTarget.COPILOT)

        val factCheckPrompt = """
            以下の内容に事実誤認がないか確認し、必要なら修正してください。
            
            $summaryBuffer
        """.trimIndent()

        Handler(Looper.getMainLooper()).postDelayed({
            injectPrompt(factCheckPrompt)
        }, prefs.allAiDelayMs)
    }

    fun onFactCheckResult(text: String) {
        onDone?.invoke(text)
    }
}
