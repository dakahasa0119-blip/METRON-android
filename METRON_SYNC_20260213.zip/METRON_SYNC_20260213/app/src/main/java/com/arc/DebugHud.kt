package com.arc

import android.app.Activity
import android.view.LayoutInflater
import android.widget.TextView

class DebugHud(
    private val activity: Activity,
    private val prefs: Prefs
) {

    private lateinit var view: TextView

    fun attach() {
        val inflater = LayoutInflater.from(activity)
        view = inflater.inflate(R.layout.debug_hud, null) as TextView
        activity.addContentView(view, view.layoutParams)
    }

    fun update(status: String) {
        if (::view.isInitialized) {
            view.text = status
        }
    }
}
