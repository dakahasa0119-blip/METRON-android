package com.arc

import android.util.Log

object Util {

    fun log(tag: String, msg: String) {
        Log.d(tag, msg)
    }

    fun escapeJs(text: String): String {
        return text
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
    }
}
