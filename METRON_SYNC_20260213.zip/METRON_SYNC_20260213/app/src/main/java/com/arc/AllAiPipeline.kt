package com.arc

import android.os.Handler
import android.os.Looper

class AllAiPipeline(
    private val prefs: Prefs,
    private val loadAi: (AiTarget) -> Unit,
    private val injectPrompt: (String) -> Unit,
    private val onFinalResult: (String) -> Unit,
    private val hallucinationPipeline: HallucinationPipeline
) {

    private val results = mutableListOf<String>()
    private var step = 0
    private var prompt = ""

    fun start(prompt: String) {
        this.prompt = prompt
        results.clear()
        step = 0
        runNext()
    }

    fun onAiResult(text: String) {
        results.add(text)
        step++
        runNext()
    }

    private fun runNext() {
        when (step) {
            0 -> {
                loadAi(AiTarget.GEMINI)
                delayedInject(prompt)
            }
            1 -> {
                loadAi(AiTarget.CHATGPT)
                delayedInject(prompt)
            }
            2 -> {
                loadAi(AiTarget.COPILOT)
                delayedInject(prompt)
            }
            else -> {
                hallucinationPipeline.process(results) { final ->
                    onFinalResult(final)
                }
            }
        }
    }

    private fun delayedInject(text: String) {
        Handler(Looper.getMainLooper()).postDelayed({
            injectPrompt(text)
        }, prefs.allAiDelayMs)
    }
}
