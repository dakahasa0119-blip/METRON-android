package com.arc

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class WebViewManager(
    private val context: Context,
    private val prefs: Prefs,
    private val onDomError: (String) -> Unit,
    private val onAiResult: (String) -> Unit,
    private val onAutoDom: (String) -> Unit
) {

    lateinit var webView: WebView
    private var lastHeartbeat = System.currentTimeMillis()

    fun createWebView(): WebView {
        webView = WebView(context)
        setupWebView(webView)
        startHeartbeatMonitor()
        return webView
    }

    private fun setupWebView(wv: WebView) {
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.useWideViewPort = true
        wv.settings.loadWithOverviewMode = true

        wv.webChromeClient = WebChromeClient()

        wv.webViewClient = object : WebViewClient() {
            override fun onRenderProcessGone(
                view: WebView,
                detail: RenderProcessGoneDetail
            ): Boolean {
                recreateWebView()
                return true
            }
        }

        wv.addJavascriptInterface(
            JsBridge(
                onAiResult = onAiResult,
                onDomError = onDomError,
                onAutoDom = onAutoDom,
                onHeartbeat = { lastHeartbeat = System.currentTimeMillis() }
            ),
            "AndroidBridge"
        )
    }

    fun recreateWebView() {
        try {
            webView.destroy()
        } catch (_: Exception) {}

        webView = WebView(context)
        setupWebView(webView)
    }

    private fun startHeartbeatMonitor() {
        Handler(Looper.getMainLooper()).postDelayed(object : Runnable {
            override fun run() {
                val now = System.currentTimeMillis()
                if (now - lastHeartbeat > 8000) {
                    recreateWebView()
                }
                Handler(Looper.getMainLooper()).postDelayed(this, 3000)
            }
        }, 3000)
    }

    fun clearCache() {
        webView.clearCache(true)
        webView.clearHistory()
    }
}
