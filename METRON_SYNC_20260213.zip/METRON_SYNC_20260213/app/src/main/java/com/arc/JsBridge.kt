package com.arc

import android.webkit.JavascriptInterface

class JsBridge(
    private val onAiResult: (String) -> Unit,
    private val onDomError: (String) -> Unit,
    private val onAutoDom: (String) -> Unit,
    private val onHeartbeat: () -> Unit
) {

    @JavascriptInterface
    fun postMessage(text: String) {
        onAiResult(text)
    }

    @JavascriptInterface
    fun domError(type: String) {
        onDomError(type)
    }

    @JavascriptInterface
    fun autoDom(json: String) {
        onAutoDom(json)
    }

    @JavascriptInterface
    fun heartbeat() {
        onHeartbeat()
    }
}
