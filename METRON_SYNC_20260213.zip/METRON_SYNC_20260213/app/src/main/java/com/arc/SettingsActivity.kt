package com.arc

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arc.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = Prefs(this)

        setupSlotSpinner()
        loadCommonPrefs()
        setupButtons()
    }

    private fun setupSlotSpinner() {
        binding.profileSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    prefs.selectedSlotIndex = position

                    binding.experimentalJson.setText(
                        when (position) {
                            0 -> prefs.profileSlot1
                            1 -> prefs.profileSlot2
                            else -> prefs.profileSlot3
                        }
                    )
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        binding.profileSpinner.setSelection(prefs.selectedSlotIndex)
    }

    private fun loadCommonPrefs() {
        binding.gasUrl.setText(prefs.gasUrl)
        binding.sheetId.setText(prefs.sheetId)

        binding.geminiUrl.setText(prefs.geminiUrl)
        binding.chatgptUrl.setText(prefs.chatGptUrl)
        binding.copilotUrl.setText(prefs.copilotUrl)

        binding.geminiInput.setText(prefs.geminiInputSelector)
        binding.geminiSend.setText(prefs.geminiSendSelector)
        binding.geminiResp.setText(prefs.geminiResponseSelector)

        binding.chatgptInput.setText(prefs.chatGptInputSelector)
        binding.chatgptSend.setText(prefs.chatGptSendSelector)
        binding.chatgptResp.setText(prefs.chatGptResponseSelector)

        binding.copilotInput.setText(prefs.copilotInputSelector)
        binding.copilotSend.setText(prefs.copilotSendSelector)
        binding.copilotResp.setText(prefs.copilotResp.text.toString())
    }

    private fun saveCommonPrefs() {
        prefs.gasUrl = binding.gasUrl.text.toString()
        prefs.sheetId = binding.sheetId.text.toString()

        prefs.geminiUrl = binding.geminiUrl.text.toString()
        prefs.chatGptUrl = binding.chatgptUrl.text.toString()
        prefs.copilotUrl = binding.copilotUrl.text.toString()

        prefs.geminiInputSelector = binding.geminiInput.text.toString()
        prefs.geminiSendSelector = binding.geminiSend.text.toString()
        prefs.geminiResponseSelector = binding.geminiResp.text.toString()

        prefs.chatGptInputSelector = binding.chatgptInput.text.toString()
        prefs.chatGptSendSelector = binding.chatgptSend.text.toString()
        prefs.chatGptResponseSelector = binding.chatgptResp.text.toString()

        prefs.copilotInputSelector = binding.copilotInput.text.toString()
        prefs.copilotSendSelector = binding.copilotSend.text.toString()
        prefs.copilotResponseSelector = binding.copilotResp.text.toString()
    }

    private fun setupButtons() {

        binding.saveButton.setOnClickListener {
            val json = binding.experimentalJson.text.toString()

            when (prefs.selectedSlotIndex) {
                0 -> prefs.profileSlot1 = json
                1 -> prefs.profileSlot2 = json
                2 -> prefs.profileSlot3 = json
            }

            saveCommonPrefs()

            Toast.makeText(
                this,
                "スロット ${prefs.selectedSlotIndex + 1} を保存しました",
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.exportJsonButton.setOnClickListener {
            binding.exportedJson.setText(binding.experimentalJson.text.toString())
        }

        binding.importJsonButton.setOnClickListener {
            val json = binding.exportedJson.text.toString()

            when (prefs.selectedSlotIndex) {
                0 -> prefs.profileSlot1 = json
                1 -> prefs.profileSlot2 = json
                2 -> prefs.profileSlot3 = json
            }

            binding.experimentalJson.setText(json)

            Toast.makeText(this, "JSON をインポートしました", Toast.LENGTH_SHORT).show()
        }
    }
}
